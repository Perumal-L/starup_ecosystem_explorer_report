/**
 * @deprecated This file is deprecated. Import useIsMobile from "@/hooks/use-mobile" instead.
 */

import { useIsMobile as useIsMobileHook } from "@/hooks/use-mobile";

export function useIsMobile() {
  console.warn("Warning: Importing useIsMobile from components/ui is deprecated. Import from @/hooks/use-mobile instead.");
  return useIsMobileHook();
}
