export default function Footer() {
  return (
    <footer className="bg-background border-t">
      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-8 flex justify-center">
        <p className="text-center text-sm text-muted-foreground">
          © 2025 Startup Ecosystem Explorer. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
