# Startup Ecosystem Explorer

A comprehensive platform for navigating and understanding the global startup ecosystem. This platform provides data-driven insights and powerful analytics tools to help founders, investors, and ecosystem builders make better decisions.

## Features

- Global startup ecosystem mapping
- Advanced analytics and trend analysis
- Network visualization of founders, investors, and companies
- Real-time data updates
- Interactive dashboards
- Premium login system with enhanced UI

## Tech Stack

- Next.js 14
- React
- TypeScript
- Tailwind CSS
- Framer Motion
- Shadcn UI

## Getting Started

1. Clone the repository:
```bash
git clone https://github.com/yourusername/startup-ecosystem.git
cd startup-ecosystem
```

2. Install dependencies:
```bash
npm install
# or
yarn install
# or
pnpm install
```

3. Run the development server:
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

4. Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Project Structure

```
startup-ecosystem/
├── app/                    # Next.js app directory
│   ├── about/             # About page
│   ├── dashboard/         # Dashboard features
│   ├── login/            # Authentication
│   └── page.tsx          # Home page
├── components/            # Reusable components
├── public/               # Static assets
└── styles/              # Global styles
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details. 