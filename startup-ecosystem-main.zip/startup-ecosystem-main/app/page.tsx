"use client"
import HomeContent from './home-content'

export default function HomePage() {
  return <HomeContent />
}
