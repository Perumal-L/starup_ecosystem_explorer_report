"use client"
import AboutContent from "./about-content"

export default function AboutPage() {
  return <AboutContent />
}
