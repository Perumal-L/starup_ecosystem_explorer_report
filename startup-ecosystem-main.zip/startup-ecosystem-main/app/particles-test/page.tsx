"use client"
import ParticlesTestUI from "./particles-test-ui"

export default function ParticlesTestPage() {
  return <ParticlesTestUI />
}
