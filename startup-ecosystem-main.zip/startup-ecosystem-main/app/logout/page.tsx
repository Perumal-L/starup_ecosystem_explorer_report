"use client"
import LogoutForm from "./logout-form"

export default function LogoutPage() {
  return <LogoutForm />
}
