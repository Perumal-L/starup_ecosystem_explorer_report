"use client";

import FixedLoginForm from './fixed-login-form'
import './premium-login.css'
import './input-fixes.css'
import './input-reset.css' // Added new input reset CSS

export default function LoginPage() {
  return <FixedLoginForm />
}
